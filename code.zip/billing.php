 <?php

session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Prepare the SQL query using the correct table name 'patients'
$sql = "SELECT 
            i.id, 
            p.name, 
            i.service, 
            i.amount, 
            i.date 
        FROM invoices AS i 
        JOIN patients AS p ON i.patient_id = p.id 
        ORDER BY i.id DESC";

// Prepare and execute the statement
if ($stmt = $conn->prepare($sql)) {
    // Execute the query
    $stmt->execute();

    // Get the result set
    $result = $stmt->get_result();
} else {
    // Handle query preparation error
    die("Error preparing statement: " . $conn->error);
}

// Close the prepared statement
$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>All Invoices</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h3>All Invoices</h3>
    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Patient</th>
                <th>Service</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            // Loop through the results
            while ($row = $result->fetch_assoc()) { 
            ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['service']); ?></td>
                <td>₹<?php echo htmlspecialchars($row['amount']); ?></td>
                <td><?php echo htmlspecialchars($row['date']); ?></td>
                <td><a href="print_invoice.php?id=<?php echo htmlspecialchars($row['id']); ?>" class="btn btn-info btn-sm">🖨 Print</a></td>
            </tr>
            <?php 
            }
            // Free the result set
            $result->free();
            ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>