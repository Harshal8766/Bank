 <?php

// Database Connection File

$host = "sql203.infinityfree.com"; // DB host from your panel
$user = "if0_39893830";           // CORRECTED username
$pass = "VwvM1HRBhf3LUf";  // Replace with your actual password
$db   = "if0_39893830_db";         // CORRECTED DB name

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    }
    ?>
   