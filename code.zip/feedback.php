 <?php
session_start();
include 'config.php';
if (!isset($_SESSION['username'])) { header("Location: index.php"); exit(); }

if (isset($_POST['submit_feedback'])) {
    $patient_id = $_POST['patient_id'];
        $feedback = $_POST['feedback'];
            mysqli_query($conn, "INSERT INTO feedback (patient_id, feedback) VALUES ('$patient_id','$feedback')");
                $msg = "Feedback saved!";
                }
                ?>
                <!DOCTYPE html>
                <html>
                <head>
                  <title>Feedback</title>
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
                    </head>
                    <body>
                    <div class="container mt-4">
                      <h3>Patient Feedback</h3>
                        <?php if (isset($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>
                          <form method="post">
                              <div class="mb-3">
                                    <label>Select Patient</label>
                                          <select name="patient_id" class="form-control">
                                                  <?php
                                                          $res = mysqli_query($conn, "SELECT * FROM patients");
                                                                  while ($row = mysqli_fetch_assoc($res)) {
                                                                            echo "<option value='{$row['id']}'>{$row['name']} ({$row['phone']})</option>";
                                                                                    }
                                                                                            ?>
                                                                                                  </select>
                                                                                                      </div>
                                                                                                          <div class="mb-3">
                                                                                                                <label>Feedback</label>
                                                                                                                      <textarea name="feedback" class="form-control" required></textarea>
                                                                                                                          </div>
                                                                                                                              <button type="submit" name="submit_feedback" class="btn btn-info">Save</button>
                                                                                                                                </form>
                                                                                                                                  <hr>
                                                                                                                                    <h4>All Feedbacks</h4>
                                                                                                                                      <table class="table table-striped">
                                                                                                                                          <thead><tr><th>ID</th><th>Patient</th><th>Feedback</th><th>Date</th></tr></thead>
                                                                                                                                              <tbody>
                                                                                                                                                    <?php
                                                                                                                                                          $all = mysqli_query($conn, "SELECT feedback.id, patients.name, feedback.feedback, feedback.date 
                                                                                                                                                                                            FROM feedback JOIN patients ON feedback.patient_id=patients.id ORDER BY feedback.id DESC");
                                                                                                                                                                                                  while ($row = mysqli_fetch_assoc($all)) {
                                                                                                                                                                                                          echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['feedback']}</td><td>{$row['date']}</td></tr>";
                                                                                                                                                                                                                }
                                                                                                                                                                                                                      ?>
                                                                                                                                                                                                                          </tbody>
                                                                                                                                                                                                                            </table>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                            </body>
                                                                                                                                                                                                                            </html