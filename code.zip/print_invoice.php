 <?php
include("config.php");
if (!isset($_GET['id'])) die("No Invoice ID");
$id = $_GET['id'];
$res = mysqli_query($conn, "SELECT invoices.id, patients.name, patients.phone, invoices.service, invoices.amount, invoices.date 
                            FROM invoices JOIN patients ON invoices.patient_id=patients.id WHERE invoices.id=$id");
                            $inv = mysqli_fetch_assoc($res);
                            ?>
                            <!DOCTYPE html>
                            <html>
                            <head>
                              <title>Invoice #<?php echo $inv['id']; ?></title>
                                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
                                </head>
                                <body onload="window.print()">
                                <div class="container mt-4 border p-4">
                                  <h2 class="text-center text-primary">🏥 My Hospital</h2>
                                    <hr>
                                      <p><b>Invoice ID:</b> <?php echo $inv['id']; ?><br>
                                           <b>Date:</b> <?php echo $inv['date']; ?></p>
                                             <p><b>Patient:</b> <?php echo $inv['name']; ?> (<?php echo $inv['phone']; ?>)</p>
                                               <table class="table table-bordered">
                                                   <tr><th>Service</th><td><?php echo $inv['service']; ?></td></tr>
                                                       <tr><th>Amount</th><td>₹<?php echo $inv['amount']; ?></td></tr>
                                                         </table>
                                                           <p class="text-center">🙏 Thank you. Get Well Soon.</p>
                                                           </div>
                                                           </body>
                                                           </html