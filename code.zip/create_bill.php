 <?php
include 'config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_id = $_POST['patient_id'];
    $service = $_POST['service'];
    $amount = $_POST['amount'];

    if (!empty($patient_id) && !empty($service) && !empty($amount)) {
        $sql = "INSERT INTO invoices (patient_id, service, amount) 
                VALUES ('$patient_id', '$service', '$amount')";
        
        if ($conn->query($sql) === TRUE) {
            header("Location: invoices.php?success=1");
            exit();
        } else {
            echo "❌ MySQL Error: " . $conn->error;
        }
    } else {
        echo "⚠️ Please fill all fields.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Bill</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2 class="mb-4">Create Bill</h2>
    <form method="post" action="">
        <div class="mb-3">
            <label class="form-label">Select Patient</label>
            <select name="patient_id" class="form-control" required>
                <?php
                $patients = $conn->query("SELECT id, name FROM patients");
                while ($row = $patients->fetch_assoc()) {
                    echo "<option value='{$row['id']}'>{$row['name']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Service</label>
            <input type="text" name="service" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Amount</label>
            <input type="number" name="amount" step="0.01" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Generate Bill</button>
    </form>
</body>
</html