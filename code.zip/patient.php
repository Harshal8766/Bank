 <?php
session_start();
include("config.php");
if (!isset($_SESSION['username'])) { header("Location: index.php"); exit(); }

if (isset($_POST['add_patient'])) {
    $name = $_POST['name'];
        $age = $_POST['age'];
            $gender = $_POST['gender'];
                $phone = $_POST['phone'];
                    mysqli_query($conn, "INSERT INTO patients (name, age, gender, phone) VALUES ('$name','$age','$gender','$phone')");
                        $msg = "Patient added successfully!";
                        }
                        ?>
                        <!DOCTYPE html>
                        <html>
                        <head>
                          <title>Add Patient</title>
                            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
                            </head>
                            <body>
                            <div class="container mt-4">
                              <h3>Add Patient</h3>
                                <?php if (isset($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>
                                  <form method="post">
                                      <div class="mb-3">
                                            <label>Name</label>
                                                  <input type="text" name="name" class="form-control" required>
                                                      </div>
                                                          <div class="mb-3">
                                                                <label>Age</label>
                                                                      <input type="number" name="age" class="form-control" required>
                                                                          </div>
                                                                              <div class="mb-3">
                                                                                    <label>Gender</label>
                                                                                          <select name="gender" class="form-control">
                                                                                                  <option>Male</option>
                                                                                                          <option>Female</option>
                                                                                                                </select>
                                                                                                                    </div>
                                                                                                                        <div class="mb-3">
                                                                                                                              <label>Phone</label>
                                                                                                                                    <input type="text" name="phone" class="form-control" required>
                                                                                                                                        </div>
                                                                                                                                            <button type="submit" name="add_patient" class="btn btn-primary">Save</button>
                                                                                                                                              </form>
                                                                                                                                              </div>
                                                                                                                                              </body>
                                                                                                                                              </html