 <?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
        exit();
        }
        ?>
        <!DOCTYPE html>
        <html>
        <head>
          <title>Dashboard</title>
            <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <!-- Bootstrap -->
                  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
                  </head>
                  <body>
                  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
                    <div class="container-fluid">
                        <a class="navbar-brand" href="#">🏥 Hospital Billing</a>
                            <div>
                                  <span class="text-white me-3">Hello, <?php echo $_SESSION['username']; ?></span>
                                        <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
                                            </div>
                                              </div>
                                              </nav>

                                              <div class="container mt-4">
                                                <div class="row g-4">
                                                    <div class="col-md-3">
                                                          <a href="patient.php" class="btn btn-outline-primary w-100 p-4">➕ Add Patient</a>
                                                              </div>
                                                                  <div class="col-md-3">
                                                                        <a href="billing.php" class="btn btn-outline-success w-100 p-4">💰 Generate Bill</a>
                                                                            </div>
                                                                                <div class="col-md-3">
                                                                                      <a href="invoice.php" class="btn btn-outline-warning w-100 p-4">🧾 View Invoices</a>
                                                                                          </div>
                                                                                              <div class="col-md-3">
                                                                                                    <a href="feedback.php" class="btn btn-outline-info w-100 p-4">📝 Feedback</a>
                                                                                                        </div>
                                                                                                          </div>
                                                                                                          </div>
                                                                                                          </body>
                                                                                                          </html